package model;

public abstract class promo {
    public abstract int hitungPotongan(int total);
}

