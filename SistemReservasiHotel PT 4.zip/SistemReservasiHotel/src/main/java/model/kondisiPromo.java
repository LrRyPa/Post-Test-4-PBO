package model;

public interface kondisiPromo {
    boolean cekKondisi(Kamar kamar, int malam);
}
